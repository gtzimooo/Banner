#!/bin/bash

echo "🔴 Iniciando instalação do Search Logs Bot 🔴"

# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Python e pip se não existirem
sudo apt install python3 python3-pip -y

# Instalar dependências do bot
pip3 install -r requirements.txt

echo "✅ Instalação concluída!"
echo "⚠️ Lembre-se de editar o arquivo bot.py e colocar seu TOKEN do BotFather."
echo "🚀 Para rodar o bot: python3 bot.py"
