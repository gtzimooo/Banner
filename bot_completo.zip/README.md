# 🔴 Search Logs Bot - Telegram

Este é um bot profissional para busca em arquivos de logs (TXT) de grande porte, com sistema de monetização e controle administrativo.

## ✨ Funcionalidades

- **Busca Eficiente**: Leitura linha a linha otimizada para arquivos de 10GB+.
- **Sistema de Teste**: 3 buscas gratuitas para novos usuários.
- **Acesso VIP**: Sistema de pagamento (R$ 25,00) para buscas ilimitadas.
- **Painel Admin**: Comandos exclusivos para gerenciar acessos e ver estatísticas.
- **Interface Premium**: Design com tema vermelho e mensagens organizadas.

## 🚀 Como Instalar na sua VPS Ubuntu

1. **Clone ou suba os arquivos** para sua VPS.
2. **Dê permissão de execução** ao script de instalação:
   ```bash
   chmod +x install.sh
   ```
3. **Execute a instalação**:
   ```bash
   ./install.sh
   ```
4. **Configure seu Token**:
   - Abra o arquivo `bot.py` e procure por `TOKEN = 'SEU_TOKEN_AQUI'`.
   - Substitua pelo token que você recebeu do [@BotFather](https://t.me/BotFather).
5. **Inicie o Bot**:
   ```bash
   python3 bot.py
   ```

## 👑 Comandos de Administrador

Apenas o ID `8766981973` pode usar estes comandos:

- `/add_acesso <id>`: Libera o VIP para um usuário.
- `/remover_acesso <id>`: Remove o VIP de um usuário.
- `/users`: Lista todos os usuários e seus status.
- `/stats`: Mostra estatísticas de uso do bot.

## 👤 Comandos de Usuário

- `/start`: Inicia o bot e mostra o menu.
- `/busca <termo>`: Realiza a pesquisa nos logs.
- `/perfil`: Mostra o status da conta e buscas restantes.
- `/ajuda`: Informações de suporte.

## ⚙️ Configurações Adicionais

- O arquivo de logs deve estar em: `/root/dx.txt`
- Para mudar o caminho, edite a variável `LOG_FILE_PATH` no `bot.py`.
- O preço e o limite de buscas grátis também podem ser alterados no topo do arquivo `bot.py`.

---
Desenvolvido com foco em performance e estética. 🔴
