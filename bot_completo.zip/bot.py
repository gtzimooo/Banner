import os
import time
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import database

# ==========================================
# CONFIGURAÇÕES - EDITE APENAS ESTA PARTE
# ==========================================
TOKEN = '8379201936:AAFp_h9fWJ3gELStDNyOBCmri_Yr0Uagm4w'
ADMIN_ID = 8766981973
CONTATO_COMPRA = "5579936180140" # Número de contato para compra
LOG_FILE_PATH = '/root/dx.txt'
BANNER_PATH = 'banner_nuvem_vermelha.png'
FREE_SEARCHES_LIMIT = 3
ACCESS_PRICE = 25.00
# ==========================================

# Configuração de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Inicializar banco de dados
database.init_db()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "Usuário"
    
    # Adicionar usuário ao banco de dados se não existir
    is_admin = 1 if user_id == ADMIN_ID else 0
    database.add_user(user_id, username, is_admin)
    
    # Mensagem de boas-vindas profissional com tema vermelho
    welcome_message = (
        "🔴 **BEM-VINDO AO SEARCH LOGS BOT** 🔴\n\n"
        "O bot mais potente para busca em logs! 🚀\n\n"
        "🔍 **Comandos Disponíveis:**\n"
        "• `/busca <termo>` - Pesquisa no arquivo de logs\n"
        "• `/perfil` - Veja seu status e buscas restantes\n"
        "• `/ajuda` - Informações de suporte\n\n"
        "💎 **Vantagens do Acesso VIP:**\n"
        "• Buscas ilimitadas\n"
        "• Resultados completos em TXT\n"
        "• Suporte prioritário\n\n"
        "💰 **Preço:** R$ 25,00 (Acesso Permanente)\n"
    )
    
    if user_id == ADMIN_ID:
        welcome_message += (
            "\n👑 **COMANDOS DE ADMINISTRADOR:**\n"
            "• `/add_acesso <id>` - Dar acesso VIP\n"
            "• `/remover_acesso <id>` - Remover acesso VIP\n"
            "• `/users` - Listar todos os usuários\n"
            "• `/stats` - Estatísticas do bot\n"
        )

    keyboard = [
        [InlineKeyboardButton("💳 COMPRAR ACESSO VIP", url=f"https://wa.me/{CONTATO_COMPRA}")],
        [InlineKeyboardButton("🔍 FAZER UMA BUSCA", callback_data='help_busca')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Enviar banner se existir
    if os.path.exists(BANNER_PATH):
        with open(BANNER_PATH, 'rb') as photo:
            await update.message.reply_photo(photo=photo, caption=welcome_message, reply_markup=reply_markup, parse_mode='Markdown')
    else:
        await update.message.reply_text(welcome_message, reply_markup=reply_markup, parse_mode='Markdown')

async def busca(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data = database.get_user(user_id)
    
    if not user_data:
        await update.message.reply_text("Erro ao carregar seus dados. Tente /start novamente.")
        return

    # Verificar acesso
    searches_count = user_data[2]
    has_access = user_data[3]
    is_admin = user_data[4]

    if not has_access and not is_admin and searches_count >= FREE_SEARCHES_LIMIT:
        keyboard = [[InlineKeyboardButton("💳 COMPRAR ACESSO VIP", url=f"https://wa.me/{CONTATO_COMPRA}")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "🔴 **LIMITE DE BUSCAS GRATUITAS ATINGIDO!** 🔴\n\n"
            "Você já utilizou suas 3 buscas de teste.\n"
            "Para continuar buscando, adquira o acesso permanente por apenas **R$ 25,00**.\n\n"
            "Fale comigo agora para liberar seu acesso!",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        return

    # Verificar se o usuário forneceu um termo de busca
    if not context.args:
        await update.message.reply_text("❌ Por favor, forneça um termo de busca. Exemplo: `/busca exemplo.com`", parse_mode='Markdown')
        return

    search_term = " ".join(context.args)
    status_msg = await update.message.reply_text(f"🔍 **Buscando por:** `{search_term}`...\n⏳ *Aguarde, o arquivo é grande e pode demorar.*", parse_mode='Markdown')

    # Realizar a busca no arquivo
    results = []
    try:
        # Verifica se o arquivo existe
        if not os.path.exists(LOG_FILE_PATH):
            await status_msg.edit_text(f"❌ Erro: Arquivo de logs não encontrado em `{LOG_FILE_PATH}`.")
            return

        start_time = time.time()
        # Busca sem limite de resultados
        with open(LOG_FILE_PATH, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                if search_term.lower() in line.lower():
                    results.append(line.strip())
        
        end_time = time.time()
        duration = round(end_time - start_time, 2)

        if results:
            # Incrementar contagem de buscas para usuários não-vips
            if not has_access and not is_admin:
                database.increment_searches(user_id)
            
            # Criar arquivo de resultado
            result_file_name = f"resultado_{user_id}_{int(time.time())}.txt"
            with open(result_file_name, 'w', encoding='utf-8') as rf:
                rf.write(f"Resultados da busca por: {search_term}\n")
                rf.write(f"Tempo de busca: {duration} segundos\n")
                rf.write("-" * 50 + "\n")
                for res in results:
                    rf.write(res + "\n")

            await status_msg.delete()
            with open(result_file_name, 'rb') as rf:
                await update.message.reply_document(
                    document=rf,
                    filename=f"resultado_{search_term}.txt",
                    caption=f"✅ **Busca concluída!**\n\n🔍 Termo: `{search_term}`\n⏱ Tempo: `{duration}s`\n📄 Resultados: `{len(results)}`",
                    parse_mode='Markdown'
                )
            os.remove(result_file_name)
        else:
            await status_msg.edit_text(f"❌ Nenhum resultado encontrado para: `{search_term}`\n⏱ Tempo: `{duration}s`", parse_mode='Markdown')

    except Exception as e:
        logging.error(f"Erro na busca: {e}")
        await status_msg.edit_text("❌ Ocorreu um erro interno ao processar sua busca.")

# Comandos de Administrador
async def add_acesso(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    if not context.args:
        await update.message.reply_text("❌ Uso correto: `/add_acesso <user_id>`")
        return

    try:
        target_id = int(context.args[0])
        database.grant_access(target_id)
        await update.message.reply_text(f"✅ Acesso VIP concedido ao ID: `{target_id}`", parse_mode='Markdown')
        try:
            await context.bot.send_message(target_id, "🎉 **PARABÉNS!** Seu acesso VIP foi ativado pelo administrador. Agora você tem buscas ilimitadas!", parse_mode='Markdown')
        except:
            pass
    except ValueError:
        await update.message.reply_text("❌ ID inválido.")

async def remover_acesso(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    if not context.args:
        await update.message.reply_text("❌ Uso correto: `/remover_acesso <user_id>`")
        return

    try:
        target_id = int(context.args[0])
        database.revoke_access(target_id)
        await update.message.reply_text(f"🚫 Acesso VIP removido do ID: `{target_id}`", parse_mode='Markdown')
    except ValueError:
        await update.message.reply_text("❌ ID inválido.")

async def list_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    users = database.get_all_users()
    if not users:
        await update.message.reply_text("Nenhum usuário cadastrado.")
        return

    msg = "👥 **LISTA DE USUÁRIOS:**\n\n"
    for user in users:
        status = "💎 VIP" if user[3] else "🆓 FREE"
        msg += f"• ID: `{user[0]}` | User: @{user[1]} | Buscas: `{user[2]}` | Status: {status}\n"
    
    if len(msg) > 4000:
        file_name = "usuarios_lista.txt"
        with open(file_name, "w") as f:
            f.write(msg)
        with open(file_name, "rb") as f:
            await update.message.reply_document(document=f, filename="usuarios.txt")
        os.remove(file_name)
    else:
        await update.message.reply_text(msg, parse_mode='Markdown')

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    users = database.get_all_users()
    total_users = len(users)
    vip_users = sum(1 for u in users if u[3])
    total_searches = sum(u[2] for u in users)

    stats_msg = (
        "📊 **ESTATÍSTICAS DO BOT**\n\n"
        f"👥 Total de Usuários: `{total_users}`\n"
        f"💎 Usuários VIP: `{vip_users}`\n"
        f"🆓 Usuários Free: `{total_users - vip_users}`\n"
        f"🔍 Total de Buscas Realizadas: `{total_searches}`\n"
    )
    await update.message.reply_text(stats_msg, parse_mode='Markdown')

async def perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data = database.get_user(user_id)
    
    if not user_data:
        await update.message.reply_text("Use /start para carregar seu perfil.")
        return

    status = "💎 VIP (Ilimitado)" if user_data[3] or user_data[4] else f"🆓 FREE ({FREE_SEARCHES_LIMIT - user_data[2]} restantes)"
    
    perfil_msg = (
        "👤 **SEU PERFIL**\n\n"
        f"🆔 ID: `{user_id}`\n"
        f"📊 Status: {status}\n"
        f"🔍 Buscas Realizadas: `{user_data[2]}`\n"
    )
    await update.message.reply_text(perfil_msg, parse_mode='Markdown')

async def ajuda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ajuda_msg = (
        "❓ **AJUDA & SUPORTE**\n\n"
        "Este bot realiza buscas em grandes arquivos de logs.\n\n"
        "• Para buscar, use: `/busca termo` ou `/busca url`\n"
        "• Novos usuários têm 3 buscas grátis.\n"
        "• O acesso VIP custa R$ 25,00 e é permanente.\n\n"
        f"📞 Para comprar, fale com: [Clique Aqui](https://wa.me/{CONTATO_COMPRA})"
    )
    await update.message.reply_text(ajuda_msg, parse_mode='Markdown', disable_web_page_preview=True)

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()

    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("busca", busca))
    app.add_handler(CommandHandler("perfil", perfil))
    app.add_handler(CommandHandler("ajuda", ajuda))
    app.add_handler(CommandHandler("add_acesso", add_acesso))
    app.add_handler(CommandHandler("remover_acesso", remover_acesso))
    app.add_handler(CommandHandler("users", list_users))
    app.add_handler(CommandHandler("stats", stats))

    print("Bot iniciado...")
    app.run_polling()
